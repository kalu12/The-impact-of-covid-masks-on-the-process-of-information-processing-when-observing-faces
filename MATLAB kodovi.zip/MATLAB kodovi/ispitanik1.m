clear all
clc
close all

data = csvread('ispitanik2.csv',1,0);
id = data(:,7);
t = data(:,1);
ch1 = data(:,3);
ch2 = data(:,4);
ch3 = data(:,5);
ch4 = data(:,6);
s = size(id);

for i = 1:s(1)
    if id(i) == 33025
        ss1 = i;
        break
    end
end

for i = ss1:s(1)
    if id(i) == 32780
        se1 = i;
        break
    end
end

d = se1 - ss1;

ss1 = find(id == 33025);
ss2 = find(id == 33026);
ss3 = find(id == 33027);
ss4 = find(id == 33030);

se1 = ss1 + d;
se2 = ss2 + d;
se3 = ss3 + d;
se4 = ss4 + d;

fs = 200;
[b,a] = butter(3,[0.1 15]/fs*2);
ch3filt = filtfilt(b,a,ch3);
ch1filt = filtfilt(b,a,ch1);
ch2filt = filtfilt(b,a,ch2);
ch4filt = filtfilt(b,a,ch4);

t1 = 0:1/fs:600/fs-1/fs;
% line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

 for i = 1:32
       
       pmch3 = zeros(600,1);
       pmch3 = pmch3 + ch3filt(ss2(i):se2(i)) + ch3filt(ss4(i):se4(i));
%        figure(1)
%        plot(t1,pmch3)
%        title(['Stimulus: ',num2str(i),'.']);
%        line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

   
       
 end
 
figure(1)
plot(t1,pmch3/64)
title('Kanal 3 lice sa maskom')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])


 for i = 1:30
       
       pch3 = zeros(600,1);
       pch3 = pch3 + ch3filt(ss1(i):se1(i)) + ch3filt(ss3(i):se3(i));
%         figure(2)
%         plot(t1,pch3)
%         title(['Stimulus: ',num2str(i),'.']);
%         line([0.3, 0.3], [-100, 100], 'Color', [0 1 0])
%         pause

   
       
 end
figure(2)
plot(t1,pch3/60)
title('Kanal 3 lice bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

k = 0; 
  for i = 4:27
       if i~=7 && i~=10  && i~=17 && i~=23 && i~=24 
       k = k+1;
       pch1 = zeros(600,1);
       pch1 = pch1 + ch1filt(ss1(i):se1(i)) + ch1filt(ss3(i):se3(i));
%         figure(3)
%         plot(t1,pch1)
%         title(['Stimulus: ',num2str(i),'.']);
%         line([0.3, 0.3], [-100, 100], 'Color', [0 1 0]);
%         pause
       end
  end
  
figure(3)
plot(t1,pch1/38)
title('Kanal 1 lice bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

for i = 4:28
    if i~=8 && i~=14 && i~=16 && i~=18 && i~=24 && i~=28 
       pmch1 = zeros(600,1);
       pmch1 = pmch1 + ch1filt(ss2(i):se2(i)) + ch1filt(ss4(i):se4(i));
%          figure(4)
%          plot(t1,pmch1)
%           title(['Stimulus: ',num2str(i),'.']);
%           line([0.3, 0.3], [-100, 100], 'Color', [0 1 0])
%           pause
    end
            
end
 
figure(4)
plot(t1,pmch1/38)
title('Kanal 1 lice sa maskom')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

 for i = 1:30


       pch2 = zeros(600,1);
       pch2 = pch2 + ch2filt(ss1(i):se1(i)) + ch2filt(ss3(i):se3(i));
%        figure(5)
%        plot(t1,pch2)
%        title(['Stimulus: ',num2str(i),'.']);
%        line([0.3, 0.3], [-100, 100], 'Color', [0 1 0]);

       

  end
  
 figure(5)
 plot(t1,pch2/60)
 title('Kanal 2 lice bez maske')
 xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
 line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

m = 0;

for i = 1:32
%        if i~=8 && i~=14 && i~=16 && i~=18  
%        m = m+1;
       pmch2 = zeros(600,1);
       pmch2 = pmch2 + ch2filt(ss2(i):se2(i)) + ch2filt(ss4(i):se4(i));
%         figure(6)
%         plot(t1,pmch2)
%         title(['Stimulus: ',num2str(i),'.']);
%         line([0.3, 0.3], [-100, 100], 'Color', [0 1 0])
%         pause
%        end


            
end
 
  figure(6)
  plot(t1,pmch2/40)
  title('Kanal 2 lice sa maskom')
  xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
  line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

  
   for i = 1:30


       pch4 = zeros(600,1);
       pch4 = pch4 + ch4filt(ss1(i):se1(i)) + ch4filt(ss3(i):se3(i));
%        figure(7)
%        plot(t1,pch2)
%        title(['Stimulus: ',num2str(i),'.']);
%        line([0.3, 0.3], [-100, 100], 'Color', [0 1 0]);

       

  end
  
 figure(7)
 plot(t1,pch4/64)
 title('Kanal 4 lice bez maske')
 xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
 line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

m = 0;

for i = 1:32
%        if i~=8 && i~=14 && i~=16 && i~=18  
%        m = m+1;
       pmch4 = zeros(600,1);
       pmch4 = pmch4 + ch4filt(ss2(i):se2(i)) + ch4filt(ss4(i):se4(i));
%         figure(8)
%         plot(t1,pmch2)
%         title(['Stimulus: ',num2str(i),'.']);
%         line([0.3, 0.3], [-100, 100], 'Color', [0 1 0])
%         pause
%        end


            
end
 
  figure(8)
  plot(t1,pmch4/64)
  title('Kanal 4 lice sa maskom')
  xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
  line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])


