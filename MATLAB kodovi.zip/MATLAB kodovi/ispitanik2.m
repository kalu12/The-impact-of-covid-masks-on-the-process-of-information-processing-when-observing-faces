clear all
clc
close all

data = csvread('ispitanik1.csv',1,0);
id = data(:,7);
t = data(:,1);
ch1 = data(:,3);
ch2 = data(:,4);
ch3 = data(:,5);
ch4 = data(:,6);
s = size(id);

for i = 1:s(1)
    if id(i) == 33025
        ss1 = i;
        break
    end
end

for i = ss1:s(1)
    if id(i) == 32780
        se1 = i;
        break
    end
end

d = se1 - ss1;

ss1 = find(id == 33025);
ss2 = find(id == 33026);
ss3 = find(id == 33027);
ss4 = find(id == 33030);
ss5 = find(id == 33031);
ss6 = find(id == 33032);
ss7 = find(id == 33033);
ss8 = find(id == 33040);

se1 = ss1 + d;
se2 = ss2 + d;
se3 = ss3 + d;
se4 = ss4 + d;
se5 = ss5 + d;
se6 = ss6 + d;
se7 = ss7 + d;
se8 = ss8 + d;

fs = 200;
[b,a] = butter(3,[0.1 15]/fs*2);
ch3filt = filtfilt(b,a,ch3);
ch1filt = filtfilt(b,a,ch1);
ch2filt = filtfilt(b,a,ch2);
ch4filt = filtfilt(b,a,ch4);




% pbmch1 = ch1(ss1(1):se1(1)) + ch1(ss1(2):se1(2)) + ch1(ss1(3):se1(3)) + ch1(ss1(4):se1(4)) + ch1(ss1(5):se1(5)) + ch1(ss1(6):se1(6)) + ch1(ss1(7):se1(7)) + ch1(ss1(8):se1(8)) + ch1(ss1(9):se1(9)) + ch1(ss1(10):se1(10)) + ch1(ss1(11):se1(11)) + ch1(ss1(12):se1(12)) + ch1(ss1(13):se1(13)) + ch1(ss1(14):se1(14)) +ch1(ss1(15):se1(15)) + ch1(ss1(16):se1(16)) + ch1(ss1(17):se1(17)) + ch1(ss1(18):se1(18)) + ch1(ss1(19):se1(19)) + ch1(ss1(20):se1(20)) + ch1(ss3(1):se3(1)) + ch1(ss3(2):se3(2)) + ch1(ss3(3):se3(3)) + ch1(ss3(4):se3(4)) + ch1(ss3(5):se3(5)) + ch1(ss3(6):se3(6)) + ch1(ss3(7):se3(7)) + ch1(ss3(8):se3(8)) + ch1(ss3(9):se3(9)) + ch1(ss3(10):se3(10)) + ch1(ss3(11):se3(11)) + ch1(ss3(12):se3(12)) + ch1(ss3(13):se3(13)) + ch1(ss3(14):se3(14)) + ch1(ss3(15):se3(15)) + ch1(ss3(16):se3(16)) + ch1(ss3(17):se3(17)) + ch1(ss3(18):se3(18)) + ch1(ss3(19):se3(19)) + ch1(ss3(20):se3(20));

t1 = 0:1/fs:601/fs-1/fs;
% figure(1)
% hold all
% line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

  for i = 1:16
 % ovo racuna za poznata lica sa i bez maske za kanal 3      
       pmch3 = zeros(601,1);
       pmch3 = pmch3 + ch3filt(ss2(i):se2(i)) + ch3filt(ss4(i):se4(i)) + ch3filt(ss1(i):se1(i)) + ch3filt(ss3(i):se3(i)) ;
%        figure(1)
%        plot(t1,pmch3)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
  end
  
  for i = 1:16
       
       pmch2 = zeros(601,1);
       pmch2 = pmch2 + ch2filt(ss2(i):se2(i)) + ch2filt(ss4(i):se4(i)) + ch2filt(ss1(i):se1(i)) + ch2filt(ss3(i):se3(i));
%        figure(1)
%        plot(t1,pmch2)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
  end
  
 for i = 1:16
       
       pmch4 = zeros(601,1);
       pmch4 = pmch4 + ch4filt(ss2(i):se2(i)) + ch4filt(ss4(i):se4(i)) + ch4filt(ss1(i):se1(i)) + ch4filt(ss3(i):se3(i)) ;
%        figure(1)
%        plot(t1,pmch4)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
 end
 for i = 1:16
       
       pmch1 = zeros(601,1);
       pmch1 = pmch1 + ch1filt(ss2(i):se2(i)) + ch1filt(ss4(i):se4(i)) + ch1filt(ss1(i):se1(i)) + ch1filt(ss3(i):se3(i));
%        figure(1)
%        plot(t1,pmch1)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
 end
 
 for i = 1:16
       % nepoznato sa i bez maske
       npmch3 = zeros(601,1);
       npmch3 = npmch3 + ch3filt(ss5(i):se5(i)) + ch3filt(ss6(i):se6(i)) + ch3filt(ss7(i):se7(i)) + ch3filt(ss8(i):se8(i)) ;
%        figure(1)
%        plot(t1,pmch3)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
  end
  
  for i = 1:16
       
       npmch2 = zeros(601,1);
       npmch2 = npmch2 + ch2filt(ss5(i):se5(i)) + ch2filt(ss6(i):se6(i)) + ch2filt(ss7(i):se7(i)) + ch2filt(ss8(i):se8(i));
%        figure(1)
%        plot(t1,pmch2)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
  end
  
 for i = 1:16
       
       npmch4 = zeros(601,1);
       npmch4 = npmch4 + ch4filt(ss5(i):se5(i)) + ch4filt(ss6(i):se6(i)) + ch4filt(ss7(i):se7(i)) + ch4filt(ss8(i):se8(i)) ;
%        figure(1)
%        plot(t1,pmch4)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
 end
 for i = 1:16
       
       npmch1 = zeros(601,1);
       npmch1 = npmch1 + ch1filt(ss5(i):se5(i)) + ch1filt(ss6(i):se6(i)) + ch1filt(ss7(i):se7(i)) + ch1filt(ss8(i):se8(i));
%        figure(1)
%        plot(t1,pmch1)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
  end
%   figure(10)
%   
%   subplot(4,1,1)
%   plot(t1,pmch1/52)
%   subplot(4,1,2)
%   plot(t1,pmch2/52)
%   subplot(4,1,3)
%   plot(t1,pmch3/52)
%   subplot(4,1,4)
%   plot(t1,pmch4/52)
%   ylim([-1,2]);
%   
%   figure(11)
%   subplot(4,1,1)
%   plot(t1,npmch1/52)
%   subplot(4,1,2)
%   plot(t1,npmch2/52)
%   subplot(4,1,3)
%   plot(t1,npmch3/52)
%   subplot(4,1,4)
%   plot(t1,npmch4/52)
%   ylim([-1,2]);
figure()
plot(t1,pmch1/64)
title('Kanal 1 za poznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,pmch2/64)
title('Kanal 2 za poznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,pmch3/64)
title('Kanal 3 za poznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,pmch4/64)
title('Kanal 4 za poznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])

figure()
plot(t1,npmch1/64)
title('Kanal 1 za nepoznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,npmch2/64)
title('Kanal 2 za nepoznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,npmch3/64)
title('Kanal 3 za nepoznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
figure()
plot(t1,npmch4/64)
title('Kanal 4 za nepoznato lice sa i bez maske')
xlabel('Vreme [s]')
ylabel('Amplituda [uV]')
line([0.3, 0.3], [-1, 1], 'Color', [0 1 0])
 

  
  
  %%

 for i = 1:16
       
       pbmch3 = zeros(601,1);
       pbmch3 = pbmch3 + ch3filt(ss1(i):se1(i)) + ch3filt(ss3(i):se3(i));
%        figure(1)
%        plot(t1,pbmch3)
%        title(['Stimulus: ',num2str(i),'.']);
%        pause
       
 end
 
 for i = 1:16
       
       pbmch1 = zeros(601,1);
       pbmch1 = pbmch1 + ch1filt(ss1(i):se1(i)) + ch1filt(ss3(i):se3(i));
       
 end
 
 for i = 1:16
       
       pbmch2 = zeros(601,1);
       pbmch2 = pbmch2 + ch2filt(ss1(i):se1(i)) + ch2filt(ss3(i):se3(i));
       
 end
 
 for i = 1:16
       
       pbmch4 = zeros(601,1);
       pbmch4 = pbmch4 + ch4filt(ss1(i):se1(i)) + ch4filt(ss3(i):se3(i));

       
 end
 
%  pbmch3 = pbmch3/32;
%  figure(2)
%  plot(t1,pbmch3)
%  hold on
%  line([0.3, 0.3], [min(pbmch3), max(pbmch3)], 'Color', [0 1 0])
 
 for i = 1:16
       
       pmch3 = zeros(601,1);
       pmch3 = pmch3 + ch3filt(ss2(i):se2(i)) + ch3filt(ss4(i):se4(i));

       
 end
 
  for i = 1:16
       
       pmch1 = zeros(601,1);
       pmch1 = pmch1 + ch1filt(ss2(i):se2(i)) + ch1filt(ss4(i):se4(i));

       
 end
 
  for i = 1:16
       
       pmch2 = zeros(601,1);
       pmch2 = pmch2 + ch2filt(ss2(i):se2(i)) + ch2filt(ss4(i):se4(i));

       
 end
 
 for i = 1:16
       
       pmch4 = zeros(601,1);
       pmch4 = pmch4 + ch4filt(ss2(i):se2(i)) + ch4filt(ss4(i):se4(i));

       
 end
 
 for i = 1:16
       
       npmch3 = zeros(601,1);
       npmch3 = npmch3 + ch3filt(ss6(i):se6(i)) + ch3filt(ss8(i):se8(i));

       
 end
 
  for i = 1:16
       
       npmch1 = zeros(601,1);
       npmch1 = npmch1 + ch1filt(ss6(i):se6(i)) + ch1filt(ss8(i):se8(i));

       
 end
 
 for i = 1:16
       
       npmch2 = zeros(601,1);
       npmch2 = npmch2 + ch2filt(ss6(i):se6(i)) + ch2filt(ss8(i):se8(i));

       
 end
 
 for i = 1:16
       
       npmch4 = zeros(601,1);
       npmch4 = npmch4 + ch4filt(ss6(i):se6(i)) + ch4filt(ss8(i):se8(i));

       
 end
 
 for i = 1:16
       
       npbmch4 = zeros(601,1);
       npbmch4 = npbmch4 + ch4filt(ss5(i):se5(i)) + ch4filt(ss7(i):se7(i));

       
 end
 
  for i = 1:16
       
       npbmch3 = zeros(601,1);
       npbmch3 = npbmch3 + ch3filt(ss5(i):se5(i)) + ch3filt(ss7(i):se7(i));

       
  end
 
   for i = 1:16
       
       npbmch2 = zeros(601,1);
       npbmch2 = npbmch2 + ch2filt(ss5(i):se5(i)) + ch2filt(ss7(i):se7(i));

       
   end
  for i = 1:16
       
       npbmch1 = zeros(601,1);
       npbmch1 = npbmch1 + ch1filt(ss5(i):se5(i)) + ch1filt(ss7(i):se7(i));

       
  end
 
 
  figure()
  subplot(4,4,1)
  plot(t1,pbmch1/32)
  subplot(4,4,2)
  plot(t1,pmch1/32)
  subplot(4,4,3)
  plot(t1,npbmch1/32)
  subplot(4,4,4)
  plot(t1,npmch1/32)
  
  subplot(4,4,5)
  plot(t1,pbmch2/32)
  subplot(4,4,6)
  plot(t1,pmch2/32)
  subplot(4,4,7)
  plot(t1,npbmch2/32)
  subplot(4,4,8)
  plot(t1,npmch2/32)
 
  
  subplot(4,4,9)
  plot(t1,pbmch3/32)
  subplot(4,4,10)
  plot(t1,pmch3/32)
  subplot(4,4,11)
  plot(t1,npbmch3/32)
  subplot(4,4,12)
  plot(t1,npmch3/32)
  
  subplot(4,4,13)
  plot(t1,pbmch4/32)
  subplot(4,4,14)
  plot(t1,pmch4/32)
  subplot(4,4,15)
  plot(t1,npbmch4/32)
  subplot(4,4,16)
  plot(t1,npmch4/32)
  
  
  

  
  
  
%  pbmch3 = pbmch3/32;
%  figure(2)
%  plot(t1,pbmch3)
%  hold on
%  line([0.3, 0.3], [min(pbmch3), max(pbmch3)], 'Color', [0 1 0])


% hold on
% plot(t1,y);








